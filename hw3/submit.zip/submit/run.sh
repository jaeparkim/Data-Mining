# python3 Assign3.py energydata_complete.csv 0.01

# python3 Assign3.py energydata_complete.csv 

